
html

<?php
$a = 10;
$b = 23;
?>

<h1>Hello, welcome to my site!</h1>

<?php echo "a + b = ".($a + $b); ?>

<br>

