
<?php echo '2 + 2 = '.(2 + 2); ?>

<br><br>

