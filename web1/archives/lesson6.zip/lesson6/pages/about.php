<?php if (!defined('INDIRECT_ACCESS')) die('!'); ?>

<h1>Это страница о нас</h1>
