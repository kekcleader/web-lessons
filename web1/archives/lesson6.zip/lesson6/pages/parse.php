<?php if (!defined('INDIRECT_ACCESS')) die('!'); ?>

<h1>Это Parse</h1>

<a href="?">Main</a><br>
