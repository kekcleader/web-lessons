<?php if (!defined('INDIRECT_ACCESS')) die('!'); ?>

<h1>Это главная страница</h1>

<a href="?page=parse">Parse</a><br>
<a href=".">Main</a><br>
<a href="?page=main">Wrong Main</a><br>
<a href="?page=hello">Hello</a><br>
<a href="?page=about">About</a>
