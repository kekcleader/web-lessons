<?php if (!defined('INDIRECT_ACCESS')) die('!'); ?>

<h1>404 Страница не найдена</h1>
