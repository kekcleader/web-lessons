<?php if (!defined('INDIRECT_ACCESS')) die('!'); ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Обработка строк</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<main class="main">
