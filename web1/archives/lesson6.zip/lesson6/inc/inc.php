<?php
if (!defined('INDIRECT_ACCESS')) die('!');

include_once 'inc/Route.php';
